# ⚡ web-pulse-cli

> Lightweight, high-performance CLI utility to audit web application performance, HTTP latency, security headers, and basic SEO health.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue.svg)](https://www.typescriptlang.org/)
[![Node.js CI](https://github.com/YOUR_USERNAME/web-pulse-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/web-pulse-cli/actions)

---

## 📌 Overview

**`web-pulse-cli`** is a developer-first tool designed to instantly evaluate response latencies, security headers, and basic SEO readiness directly from your terminal. Built with Node.js and TypeScript, it offers fast execution and human-readable feedback for web engineers, DevOps professionals, and technical founders.

---

## ✨ Features

- **⚡ Latency Benchmarking:** Accurate round-trip timing for HTTP/HTTPS requests.
- **🛡️ Security Header Check:** Inspects critical headers (`Strict-Transport-Security`, `X-Content-Type-Options`, `Content-Security-Policy`).
- **🔍 SEO Baseline Audit:** Quick checks for title tag presence, meta descriptions, and indexability signals.
- **🎨 Visual CLI Output:** Color-coded status indicators, badges, and progress spinners via `chalk` and `ora`.
- **📊 Modular Architecture:** Easily extendable codebase designed for quick CLI additions or secondary integrations.

---

## 🛠️ Prerequisites

- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

---

## 🚀 Quick Start

### Installation via Source

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/web-pulse-cli.git

# Navigate into project directory
cd web-pulse-cli

# Install dependencies
npm install

# Build TypeScript source
npm run build

# Link binary globally
npm link
```

---

## 📖 Usage

Run `web-pulse` followed by any target domain or full URL:

```bash
# Basic URL audit
web-pulse https://websummit.com

# Domain shorthand (automatically prepends https://)
web-pulse github.com
```

### Sample Output

```text
✔ Audit complete for https://websummit.com

Performance & Metrics
---------------------
Status Code     : 200 OK
Response Time   : 142 ms

Basic Health Checks
-------------------
HTTPS Secured   : PASS
Security HSTS   : PASS
Meta Description: FOUND
```

---

## 📁 Directory Structure

```text
web-pulse-cli/
├── .github/
│   └── workflows/
│       └── ci.yml             # Continuous Integration configuration
├── src/
│   └── index.ts               # CLI command logic & HTTP client runner
├── dist/                      # Compiled JS output (after npm run build)
├── .gitignore
├── LICENSE                    # MIT License
├── package.json
├── tsconfig.json
└── README.md
```

---

## 🧪 Running Tests

```bash
# Execute unit tests using Node native test runner
npm test
```

---

## 🤝 Contributing

Contributions are welcome! Follow these steps to submit your work:

1. Fork the Repository.
2. Create your Feature Branch (`git checkout -b feature/amazing-feature`).
3. Commit your Changes (`git commit -m 'feat: add support for custom user-agent'`).
4. Push to the Branch (`git push origin feature/amazing-feature`).
5. Open a Pull Request.

---

## 📄 License

Distributed under the **MIT License**. See [`LICENSE`](LICENSE) for details.
