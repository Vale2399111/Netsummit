#!/usr/bin/env node

import { Command } from 'commander';
import axios from 'axios';
import chalk from 'chalk';
import ora from 'ora';

interface AuditResult {
  url: string;
  responseTimeMs: number;
  statusCode: number;
  headers: Record<string, string>;
  checks: {
    https: boolean;
    hasMetaDescription: boolean;
    securityHeaders: boolean;
  };
}

const program = new Command();

program
  .name('web-pulse')
  .description('Audit website response time, security headers, and SEO markers')
  .version('1.0.0')
  .argument('<url>', 'URL to audit (e.g., https://example.com)')
  .action(async (targetUrl: string) => {
    let url = targetUrl;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = `https://${url}`;
    }

    const spinner = ora(`Auditing ${url}...`).start();
    const startTime = Date.now();

    try {
      const response = await axios.get(url, {
        headers: { 'User-Agent': 'WebPulse-CLI/1.0' },
        timeout: 10000,
      });

      const latency = Date.now() - startTime;
      spinner.succeed(`Audit complete for ${chalk.bold(url)}\n`);

      const audit: AuditResult = {
        url,
        responseTimeMs: latency,
        statusCode: response.status,
        headers: response.headers as Record<string, string>,
        checks: {
          https: url.startsWith('https://'),
          hasMetaDescription: typeof response.data === 'string' && response.data.includes('name="description"'),
          securityHeaders: Boolean(response.headers['strict-transport-security']),
        },
      };

      printReport(audit);
    } catch (error: any) {
      spinner.fail(`Failed to reach ${url}: ${error.message}`);
      process.exit(1);
    }
  });

function printReport(audit: AuditResult): void {
  console.log(chalk.bold.underline('Performance & Metrics'));
  console.log(`Status Code     : ${audit.statusCode === 200 ? chalk.green(audit.statusCode) : chalk.yellow(audit.statusCode)}`);
  console.log(`Response Time   : ${audit.responseTimeMs < 500 ? chalk.green(`${audit.responseTimeMs} ms`) : chalk.red(`${audit.responseTimeMs} ms`)}`);

  console.log('\n' + chalk.bold.underline('Basic Health Checks'));
  console.log(`HTTPS Secured   : ${audit.checks.https ? chalk.green('PASS') : chalk.red('FAIL')}`);
  console.log(`Security HSTS   : ${audit.checks.securityHeaders ? chalk.green('PASS') : chalk.yellow('MISSING')}`);
  console.log(`Meta Description: ${audit.checks.hasMetaDescription ? chalk.green('FOUND') : chalk.yellow('MISSING')}`);
}

program.parse(process.argv);
